import React, { useState, useEffect } from 'react';
import { Question, LeaderboardEntry, MapLocation } from '../types';
import { CheckCircle, XCircle, HelpCircle, Trophy, Timer, MapPin } from 'lucide-react';

interface QuizProps {
  questions: Question[];
  darkMode: boolean;
  locations?: MapLocation[];
}

export function Quiz({ questions, darkMode, locations = [] }: QuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('easy');
  const [showExplanation, setShowExplanation] = useState(false);
  const [playerName, setPlayerName] = useState('');
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>(() => {
    const saved = localStorage.getItem('leaderboard');
    return saved ? JSON.parse(saved) : [];
  });
  const [quizQuestions, setQuizQuestions] = useState<Question[]>([]);
  const [timeLeft, setTimeLeft] = useState(30);
  const [showHint, setShowHint] = useState(false);

  useEffect(() => {
    const filteredQuestions = questions.filter(q => q.difficulty === difficulty);
    const randomQuestions = [...filteredQuestions]
      .sort(() => Math.random() - 0.5)
      .slice(0, 3);
    setQuizQuestions(randomQuestions);
  }, [difficulty, questions]);

  useEffect(() => {
    if (selectedAnswer === null && !showResult) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleAnswer('');
            return 30;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [selectedAnswer, showResult]);

  const handleAnswer = (answer: string) => {
    setSelectedAnswer(answer);
    if (answer === quizQuestions[currentQuestion].correctAnswer) {
      setScore(score + quizQuestions[currentQuestion].points);
    }
    setShowExplanation(true);
    setTimeLeft(30);
    setShowHint(false);

    setTimeout(() => {
      setSelectedAnswer(null);
      setShowExplanation(false);
      if (currentQuestion < quizQuestions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
      } else {
        setShowResult(true);
      }
    }, 3000);
  };

  const saveScore = () => {
    if (playerName.trim()) {
      const newEntry: LeaderboardEntry = {
        name: playerName,
        score,
        difficulty,
        date: new Date().toISOString().split('T')[0]
      };
      const newLeaderboard = [...leaderboard, newEntry]
        .sort((a, b) => b.score - a.score)
        .slice(0, 10);
      setLeaderboard(newLeaderboard);
      localStorage.setItem('leaderboard', JSON.stringify(newLeaderboard));
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setTimeLeft(30);
    setShowHint(false);
    const filteredQuestions = questions.filter(q => q.difficulty === difficulty);
    const randomQuestions = [...filteredQuestions]
      .sort(() => Math.random() - 0.5)
      .slice(0, 3);
    setQuizQuestions(randomQuestions);
  };

  const getDifficultyColor = (diff: string) => {
    switch (diff) {
      case 'easy': return 'text-green-500 dark:text-green-400';
      case 'medium': return 'text-yellow-500 dark:text-yellow-400';
      case 'hard': return 'text-red-500 dark:text-red-400';
      default: return '';
    }
  };

  const getRelatedLocation = (locationId?: number) => {
    if (!locationId) return null;
    return locations.find(loc => loc.id === locationId);
  };

  if (showResult) {
    return (
      <div className="bg-gray-50 dark:bg-gray-700 p-8 rounded-xl shadow-lg transition-colors duration-200">
        <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">
          Результаты викторины
        </h2>
        <p className="text-xl mb-4 text-gray-700 dark:text-gray-200">
          Вы набрали {score} очков!
        </p>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Введите ваше имя для таблицы лидеров:
          </label>
          <input
            type="text"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 
              bg-white dark:bg-gray-800 text-gray-900 dark:text-white mb-4"
            placeholder="Ваше имя"
          />
          <button
            onClick={saveScore}
            disabled={!playerName.trim()}
            className="bg-green-600 dark:bg-green-700 text-white px-6 py-3 rounded-lg 
              hover:bg-green-700 dark:hover:bg-green-800 transition-colors duration-200
              shadow-lg shadow-green-500/20 disabled:opacity-50 disabled:cursor-not-allowed mr-4"
          >
            Сохранить результат
          </button>
        </div>

        <div className="mb-8">
          <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-white flex items-center gap-2">
            <Trophy className="text-yellow-500" size={24} />
            Таблица лидеров
          </h3>
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
            <table className="min-w-full">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Место
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Имя
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Очки
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Сложность
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Дата
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {leaderboard.map((entry, index) => (
                  <tr key={index} className={index === 0 ? 'bg-yellow-50 dark:bg-yellow-900/20' : ''}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {index + 1}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {entry.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {entry.score}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <span className={`${getDifficultyColor(entry.difficulty)} font-medium`}>
                        {entry.difficulty === 'easy' ? 'Лёгкий' : 
                         entry.difficulty === 'medium' ? 'Средний' : 'Сложный'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {entry.date}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex gap-4">
          <button
            onClick={resetQuiz}
            className="bg-blue-600 dark:bg-blue-700 text-white px-6 py-3 rounded-lg 
              hover:bg-blue-700 dark:hover:bg-blue-800 transition-colors duration-200
              shadow-lg shadow-blue-500/20"
          >
            Начать заново
          </button>
          <button
            onClick={() => {
              setDifficulty(difficulty === 'easy' ? 'medium' : difficulty === 'medium' ? 'hard' : 'easy');
              resetQuiz();
            }}
            className="bg-purple-600 dark:bg-purple-700 text-white px-6 py-3 rounded-lg 
              hover:bg-purple-700 dark:hover:bg-purple-800 transition-colors duration-200
              shadow-lg shadow-purple-500/20"
          >
            Сменить сложность
          </button>
        </div>
      </div>
    );
  }

  const question = quizQuestions[currentQuestion];

  if (!question) {
    return (
      <div className="text-center p-8">
        <p className="text-gray-700 dark:text-gray-300">Загрузка вопросов...</p>
      </div>
    );
  }

  const relatedLocation = getRelatedLocation(question.relatedLocationId);

  return (
    <div className="bg-gray-50 dark:bg-gray-700 p-8 rounded-xl shadow-lg transition-colors duration-200">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-4">
          <span className="text-sm text-gray-500 dark:text-gray-400">
            Вопрос {currentQuestion + 1} из {quizQuestions.length}
          </span>
          <span className="text-sm font-medium text-blue-600 dark:text-blue-400">
            Очки: {score}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Timer size={18} className="text-orange-500" />
            <span className="text-sm font-medium text-orange-500">
              {timeLeft} сек
            </span>
          </div>
          <span className={`text-sm font-medium ${getDifficultyColor(difficulty)}`}>
            {difficulty === 'easy' ? 'Лёгкий' : difficulty === 'medium' ? 'Средний' : 'Сложный'}
          </span>
          <button
            onClick={() => {
              setDifficulty(difficulty === 'easy' ? 'medium' : difficulty === 'medium' ? 'hard' : 'easy');
              resetQuiz();
            }}
            className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
          >
            Сменить сложность
          </button>
        </div>
      </div>
      
      <div className="mb-4">
        <h2 className="text-xl font-semibold mb-2 text-gray-800 dark:text-white">
          {question.question}
        </h2>
        <div className="flex justify-between items-center">
          <p className="text-sm text-blue-600 dark:text-blue-400">
            +{question.points} очков за правильный ответ
          </p>
          
          {relatedLocation && (
            <button
              onClick={() => setShowHint(!showHint)}
              className="flex items-center gap-1 text-sm text-red-600 dark:text-red-400 hover:underline"
            >
              <MapPin size={16} />
              {showHint ? 'Скрыть подсказку' : 'Показать подсказку на карте'}
            </button>
          )}
        </div>
      </div>
      
      {showHint && relatedLocation && (
        <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
          <p className="text-sm text-red-800 dark:text-red-200">
            Подсказка: Посмотрите на карте метку "{relatedLocation.name}" (красный маркер)
          </p>
        </div>
      )}
      
      <div className="space-y-3">
        {question.options.map((option) => (
          <button
            key={option}
            onClick={() => handleAnswer(option)}
            disabled={selectedAnswer !== null}
            className={`w-full p-4 text-left rounded-lg transition-all duration-200 
              ${selectedAnswer === option
                ? option === question.correctAnswer
                  ? 'bg-green-100 dark:bg-green-900/50 border-green-500'
                  : 'bg-red-100 dark:bg-red-900/50 border-red-500'
                : 'bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700'
              } border-2 ${
                selectedAnswer === null ? 'border-transparent' : ''
              } shadow-sm`}
          >
            <div className="flex items-center justify-between">
              <span className={`${
                selectedAnswer === null 
                  ? 'text-gray-700 dark:text-gray-200' 
                  : option === question.correctAnswer
                    ? 'text-green-700 dark:text-green-300'
                    : 'text-red-700 dark:text-red-300'
              }`}>
                {option}
              </span>
              {selectedAnswer === option && (
                option === question.correctAnswer ? 
                <CheckCircle className="text-green-500 dark:text-green-400" size={24} /> :
                <XCircle className="text-red-500 dark:text-red-400" size={24} />
              )}
            </div>
          </button>
        ))}
      </div>

      {showExplanation && question.explanation && (
        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
          <div className="flex items-start gap-3">
            <HelpCircle className="text-blue-500 dark:text-blue-400 mt-1" size={20} />
            <p className="text-blue-800 dark:text-blue-200">
              {question.explanation}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
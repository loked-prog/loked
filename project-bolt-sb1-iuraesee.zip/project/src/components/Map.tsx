import React, { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { MapLocation } from '../types';
import L from 'leaflet';

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Создаем кастомные иконки для разных типов маркеров
const createCustomIcon = (color: string) => {
  return new L.Icon({
    iconUrl: `https://cdn.rawgit.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });
};

const quizHintIcon = createCustomIcon('red');
const wonderIcon = createCustomIcon('violet');
const historicalIcon = createCustomIcon('orange');
const naturalIcon = createCustomIcon('green');

// Компонент для ограничения перемещения карты
function MapBoundary() {
  const map = useMap();
  
  useEffect(() => {
    // Устанавливаем максимальные границы карты
    const worldBounds = L.latLngBounds(
      L.latLng(-85, -180),  // Юго-западный угол
      L.latLng(85, 180)     // Северо-восточный угол
    );
    
    map.setMaxBounds(worldBounds);
    map.on('drag', () => {
      map.panInsideBounds(worldBounds, { animate: false });
    });
    
    // Ограничиваем минимальный и максимальный зум
    map.setMinZoom(2);
    map.setMaxZoom(18);
    
    return () => {
      map.off('drag');
    };
  }, [map]);
  
  return null;
}

interface MapProps {
  locations: MapLocation[];
  darkMode: boolean;
}

export function Map({ locations, darkMode }: MapProps) {
  const mapRef = useRef<L.Map | null>(null);
  
  const getMarkerIcon = (location: MapLocation) => {
    if (location.isQuizHint) {
      return quizHintIcon;
    }
    
    switch (location.type) {
      case 'wonder':
        return wonderIcon;
      case 'historical':
        return historicalIcon;
      case 'natural':
        return naturalIcon;
      default:
        return new L.Icon.Default();
    }
  };
  
  return (
    <div className="h-[500px] w-full rounded-xl overflow-hidden shadow-lg transition-shadow duration-200">
      <MapContainer
        center={[20, 0]}
        zoom={2}
        style={{ height: '100%', width: '100%' }}
        className={darkMode ? 'dark-map' : ''}
        ref={mapRef}
        maxBoundsViscosity={1.0}
        worldCopyJump={false}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url={darkMode 
            ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
            : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
          }
          noWrap={true}
        />
        <MapBoundary />
        
        {locations.map((location) => (
          <Marker 
            key={location.id} 
            position={location.coordinates}
            icon={getMarkerIcon(location)}
          >
            <Popup>
              <div className="p-2 max-w-xs">
                <h3 className="font-bold text-lg mb-2">{location.name}</h3>
                {location.imageUrl && (
                  <img
                    src={`${location.imageUrl}?auto=format&fit=crop&w=300&q=80`}
                    alt={location.name}
                    className="w-full h-32 object-cover rounded-lg mb-2"
                  />
                )}
                <p className="text-gray-600 dark:text-gray-300 text-sm">{location.description}</p>
                <div className="flex flex-wrap gap-2 mt-2">
                  <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium
                    ${location.type === 'wonder'
                      ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-200'
                      : location.type === 'historical'
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-200'
                      : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200'
                    }`}
                  >
                    {location.type === 'wonder' ? 'Чудо света'
                      : location.type === 'historical' ? 'Исторический памятник'
                      : 'Природная достопримечательность'}
                  </span>
                  
                  {location.isQuizHint && (
                    <span className="inline-block px-2 py-1 rounded-full text-xs font-medium
                      bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-200">
                      Подсказка для викторины
                    </span>
                  )}
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
      
      <div className="mt-4 bg-white dark:bg-gray-800 p-3 rounded-lg shadow-sm">
        <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Легенда карты:</h3>
        <div className="flex flex-wrap gap-3">
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <span className="text-xs text-gray-600 dark:text-gray-400">Подсказки для викторины</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-full bg-purple-500"></div>
            <span className="text-xs text-gray-600 dark:text-gray-400">Чудеса света</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-full bg-amber-500"></div>
            <span className="text-xs text-gray-600 dark:text-gray-400">Исторические памятники</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
            <span className="text-xs text-gray-600 dark:text-gray-400">Природные достопримечательности</span>
          </div>
        </div>
      </div>
    </div>
  );
}
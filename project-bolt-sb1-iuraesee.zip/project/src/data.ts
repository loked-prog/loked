import { Question, MapLocation, LeaderboardEntry } from './types';

export const geographyQuestions: Question[] = [
  // Лёгкие вопросы
  {
    id: 1,
    question: "Какая самая длинная река в мире?",
    options: ["Амазонка", "Нил", "Янцзы", "Миссисипи"],
    correctAnswer: "Нил",
    difficulty: "easy",
    explanation: "Нил - самая длинная река в мире, его длина составляет 6,650 км.",
    points: 100,
    relatedLocationId: 1
  },
  {
    id: 2,
    question: "Какая страна является самой большой по площади?",
    options: ["Китай", "США", "Россия", "Канада"],
    correctAnswer: "Россия",
    difficulty: "easy",
    explanation: "Россия - крупнейшая страна мира с площадью 17,1 млн км².",
    points: 100,
    relatedLocationId: 2
  },
  {
    id: 3,
    question: "Какой континент самый холодный?",
    options: ["Северная Америка", "Европа", "Антарктида", "Азия"],
    correctAnswer: "Антарктида",
    difficulty: "easy",
    explanation: "Антарктида - самый холодный континент со средней температурой -49°C.",
    points: 100,
    relatedLocationId: 3
  },
  {
    id: 4,
    question: "Какой океан самый большой?",
    options: ["Атлантический", "Индийский", "Тихий", "Северный Ледовитый"],
    correctAnswer: "Тихий",
    difficulty: "easy",
    explanation: "Тихий океан - крупнейший и самый глубокий океан на Земле.",
    points: 100,
    relatedLocationId: 4
  },
  {
    id: 5,
    question: "Столица Франции - это...",
    options: ["Лондон", "Париж", "Мадрид", "Рим"],
    correctAnswer: "Париж",
    difficulty: "easy",
    explanation: "Париж - столица Франции и один из крупнейших городов Европы.",
    points: 100,
    relatedLocationId: 5
  },
  // Средние вопросы
  {
    id: 6,
    question: "В какой стране находится самая высокая точка Южной Америки?",
    options: ["Бразилия", "Перу", "Чили", "Аргентина"],
    correctAnswer: "Аргентина",
    difficulty: "medium",
    explanation: "Гора Аконкагуа (6,962 м) в Аргентине - высочайшая точка Южной Америки.",
    points: 200,
    relatedLocationId: 6
  },
  {
    id: 7,
    question: "Какой пролив отделяет Европу от Африки?",
    options: ["Босфор", "Гибралтарский", "Ла-Манш", "Берингов"],
    correctAnswer: "Гибралтарский",
    difficulty: "medium",
    explanation: "Гибралтарский пролив соединяет Средиземное море с Атлантическим океаном.",
    points: 200,
    relatedLocationId: 7
  },
  {
    id: 8,
    question: "Какое озеро самое глубокое в мире?",
    options: ["Байкал", "Танганьика", "Верхнее", "Виктория"],
    correctAnswer: "Байкал",
    difficulty: "medium",
    explanation: "Озеро Байкал - самое глубокое озеро в мире с максимальной глубиной 1,642 м.",
    points: 200,
    relatedLocationId: 8
  },
  {
    id: 9,
    question: "Какая страна имеет больше всего часовых поясов?",
    options: ["США", "Россия", "Китай", "Канада"],
    correctAnswer: "Россия",
    difficulty: "medium",
    explanation: "Россия охватывает 11 часовых поясов, больше чем любая другая страна.",
    points: 200,
    relatedLocationId: 2
  },
  {
    id: 10,
    question: "Какой вулкан является самым высоким в Европе?",
    options: ["Везувий", "Этна", "Стромболи", "Гекла"],
    correctAnswer: "Этна",
    difficulty: "medium",
    explanation: "Этна на Сицилии - самый высокий действующий вулкан в Европе.",
    points: 200,
    relatedLocationId: 9
  },
  // Сложные вопросы
  {
    id: 11,
    question: "В каком году была открыта Антарктида?",
    options: ["1820", "1492", "1901", "1873"],
    correctAnswer: "1820",
    difficulty: "hard",
    explanation: "Антарктида была открыта русской экспедицией Беллинсгаузена и Лазарева в 1820 году.",
    points: 300,
    relatedLocationId: 3
  },
  {
    id: 12,
    question: "Какое озеро является самым солёным в мире?",
    options: ["Мёртвое море", "Каспийское море", "Большое Солёное озеро", "Озеро Ассаль"],
    correctAnswer: "Озеро Ассаль",
    difficulty: "hard",
    explanation: "Озеро Ассаль в Джибути имеет самую высокую концентрацию соли среди всех озёр мира.",
    points: 300,
    relatedLocationId: 10
  },
  {
    id: 13,
    question: "Какой город расположен на двух континентах?",
    options: ["Дубай", "Стамбул", "Каир", "Сингапур"],
    correctAnswer: "Стамбул",
    difficulty: "hard",
    explanation: "Стамбул расположен на двух континентах - Европе и Азии, разделённых проливом Босфор.",
    points: 300,
    relatedLocationId: 11
  },
  {
    id: 14,
    question: "Какая страна граничит с наибольшим количеством государств?",
    options: ["Россия", "Китай", "Бразилия", "Германия"],
    correctAnswer: "Китай",
    difficulty: "hard",
    explanation: "Китай граничит с 14 странами, что является мировым рекордом.",
    points: 300,
    relatedLocationId: 12
  },
  {
    id: 15,
    question: "Где находится точка пересечения всех часовых поясов?",
    options: ["Гринвич", "Северный полюс", "Экватор", "180-й меридиан"],
    correctAnswer: "Северный полюс",
    difficulty: "hard",
    explanation: "В Северном полюсе сходятся все часовые пояса, так как все меридианы пересекаются в этой точке.",
    points: 300,
    relatedLocationId: 13
  }
];

export const interestingLocations: MapLocation[] = [
  {
    id: 1,
    name: "Река Нил",
    coordinates: [26.8206, 30.8025],
    description: "Самая длинная река в мире, протекающая через 11 стран. Её длина составляет около 6,650 км.",
    type: "natural",
    imageUrl: "https://images.unsplash.com/photo-1566288623394-377af472d81b",
    isQuizHint: true
  },
  {
    id: 2,
    name: "Россия",
    coordinates: [61.5240, 105.3188],
    description: "Крупнейшая страна мира с площадью 17,1 млн км². Охватывает 11 часовых поясов.",
    type: "natural",
    imageUrl: "https://images.unsplash.com/photo-1513326738677-b964603b136d",
    isQuizHint: true
  },
  {
    id: 3,
    name: "Антарктида",
    coordinates: [-79.4063, 0.3149],
    description: "Самый холодный континент со средней температурой -49°C. Открыт в 1820 году русской экспедицией.",
    type: "natural",
    imageUrl: "https://images.unsplash.com/photo-1516444628868-7a4bd9a1e9f7",
    isQuizHint: true
  },
  {
    id: 4,
    name: "Тихий океан",
    coordinates: [0.7893, -171.0566],
    description: "Крупнейший и самый глубокий океан на Земле, занимающий треть поверхности планеты.",
    type: "natural",
    imageUrl: "https://images.unsplash.com/photo-1518122306695-c777bf5c6a6e",
    isQuizHint: true
  },
  {
    id: 5,
    name: "Париж",
    coordinates: [48.8566, 2.3522],
    description: "Столица Франции и один из крупнейших городов Европы, известный своей архитектурой и культурой.",
    type: "historical",
    imageUrl: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34",
    isQuizHint: true
  },
  {
    id: 6,
    name: "Гора Аконкагуа",
    coordinates: [-32.6532, -70.0110],
    description: "Высочайшая точка Южной Америки (6,962 м), расположенная в Аргентине в Андах.",
    type: "natural",
    imageUrl: "https://images.unsplash.com/photo-1518775053278-5a569f0be353",
    isQuizHint: true
  },
  {
    id: 7,
    name: "Гибралтарский пролив",
    coordinates: [35.9897, -5.6082],
    description: "Пролив, соединяющий Средиземное море с Атлантическим океаном и отделяющий Европу от Африки.",
    type: "natural",
    imageUrl: "https://images.unsplash.com/photo-1565861488776-4d3deb55ed1c",
    isQuizHint: true
  },
  {
    id: 8,
    name: "Озеро Байкал",
    coordinates: [53.5587, 108.1650],
    description: "Самое глубокое озеро в мире с максимальной глубиной 1,642 м, содержит 20% пресной воды планеты.",
    type: "natural",
    imageUrl: "https://images.unsplash.com/photo-1551845041-63e8e76836ea",
    isQuizHint: true
  },
  {
    id: 9,
    name: "Вулкан Этна",
    coordinates: [37.7510, 14.9934],
    description: "Самый высокий действующий вулкан в Европе, расположенный на острове Сицилия в Италии.",
    type: "natural",
    imageUrl: "https://images.unsplash.com/photo-1620649332832-e08022594d90",
    isQuizHint: true
  },
  {
    id: 10,
    name: "Озеро Ассаль",
    coordinates: [11.6546, 42.4200],
    description: "Самое солёное озеро в мире, расположенное в Джибути, с концентрацией соли выше, чем в Мёртвом море.",
    type: "natural",
    imageUrl: "https://images.unsplash.com/photo-1504618223053-559bdef9dd5a",
    isQuizHint: true
  },
  {
    id: 11,
    name: "Стамбул",
    coordinates: [41.0082, 28.9784],
    description: "Единственный город в мире, расположенный на двух континентах - Европе и Азии, разделённых проливом Босфор.",
    type: "historical",
    imageUrl: "https://images.unsplash.com/photo-1524231757912-21f4fe3a7200",
    isQuizHint: true
  },
  {
    id: 12,
    name: "Китай",
    coordinates: [35.8617, 104.1954],
    description: "Страна, граничащая с 14 государствами - больше, чем любая другая страна в мире.",
    type: "historical",
    imageUrl: "https://images.unsplash.com/photo-1547981609-4b6bfe67ca0b",
    isQuizHint: true
  },
  {
    id: 13,
    name: "Северный полюс",
    coordinates: [90, 0],
    description: "Точка, где сходятся все часовые пояса, так как все меридианы пересекаются в этой точке.",
    type: "natural",
    imageUrl: "https://images.unsplash.com/photo-1589311836499-ac5f5aca6da2",
    isQuizHint: true
  },
  {
    id: 14,
    name: "Великая Китайская стена",
    coordinates: [40.4319, 116.5704],
    description: "Одно из самых грандиозных сооружений в истории человечества, протяжённостью более 21,000 км.",
    type: "wonder",
    imageUrl: "https://images.unsplash.com/photo-1508804185872-d7badad00f7d",
    isQuizHint: false
  },
  {
    id: 15,
    name: "Пирамиды Гизы",
    coordinates: [29.9773, 31.1325],
    description: "Единственное из Семи чудес древнего мира, сохранившееся до наших дней.",
    type: "wonder",
    imageUrl: "https://images.unsplash.com/photo-1503177119275-0aa32b3a9368",
    isQuizHint: false
  },
  {
    id: 16,
    name: "Мачу-Пикчу",
    coordinates: [-13.1631, -72.5450],
    description: "Древний город инков, расположенный на высоте 2,430 метров в Перуанских Андах.",
    type: "wonder",
    imageUrl: "https://images.unsplash.com/photo-1526392060635-9d6019884377",
    isQuizHint: false
  },
  {
    id: 17,
    name: "Тадж-Махал",
    coordinates: [27.1751, 78.0421],
    description: "Мавзолей-мечеть в Индии, построенный императором Шах-Джаханом в память о жене Мумтаз-Махал.",
    type: "wonder",
    imageUrl: "https://images.unsplash.com/photo-1564507592333-c60657eea523",
    isQuizHint: false
  },
  {
    id: 18,
    name: "Колизей",
    coordinates: [41.8902, 12.4922],
    description: "Амфитеатр в центре Рима, самый большой из когда-либо построенных в Римской империи.",
    type: "historical",
    imageUrl: "https://images.unsplash.com/photo-1552832230-c0197dd311b5",
    isQuizHint: false
  }
];

export const initialLeaderboard: LeaderboardEntry[] = [
  {
    name: "Александр",
    score: 800,
    difficulty: "medium",
    date: "2024-03-15"
  },
  {
    name: "Мария",
    score: 1200,
    difficulty: "hard",
    date: "2024-03-14"
  },
  {
    name: "Дмитрий",
    score: 450,
    difficulty: "easy",
    date: "2024-03-13"
  }
];
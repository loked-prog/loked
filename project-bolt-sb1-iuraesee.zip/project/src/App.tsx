import React, { useState, useEffect } from 'react';
import { Map } from './components/Map';
import { Quiz } from './components/Quiz';
import { geographyQuestions, interestingLocations } from './data';
import { Globe, BookOpen, Sun, Moon } from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState<'map' | 'quiz'>('map');
  const [darkMode, setDarkMode] = useState(() => {
    const savedTheme = localStorage.getItem('theme');
    return savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches);
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
      <header className="bg-gradient-to-r from-blue-600 to-blue-800 dark:from-blue-800 dark:to-blue-900 text-white py-6 shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-2">
                <Globe className="text-blue-200" size={32} />
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-blue-200">
                  ГеоУчёба
                </span>
              </h1>
              <p className="mt-2 text-blue-100">Интерактивное изучение географии</p>
            </div>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
              aria-label="Переключить тему"
            >
              {darkMode ? <Sun size={24} /> : <Moon size={24} />}
            </button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="flex gap-4 mb-6">
          <button
            onClick={() => setActiveTab('map')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-all duration-200 shadow-sm
              ${activeTab === 'map'
                ? 'bg-blue-600 dark:bg-blue-700 text-white scale-105 shadow-blue-500/20'
                : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
          >
            <Globe size={20} />
            Карта
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-all duration-200 shadow-sm
              ${activeTab === 'quiz'
                ? 'bg-blue-600 dark:bg-blue-700 text-white scale-105 shadow-blue-500/20'
                : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
          >
            <BookOpen size={20} />
            Викторина
          </button>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-xl dark:shadow-gray-900/50 transition-colors duration-200">
          {activeTab === 'map' ? (
            <div>
              <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">
                Исследуйте мир
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Изучайте интересные места по всему миру. Кликните на маркеры, чтобы узнать больше. Красные маркеры - подсказки для викторины!
              </p>
              <Map locations={interestingLocations} darkMode={darkMode} />
            </div>
          ) : (
            <div>
              <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">
                Проверьте свои знания
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Ответьте на вопросы и проверьте свои знания по географии. Используйте подсказки на карте, если затрудняетесь с ответом.
              </p>
              <Quiz questions={geographyQuestions} darkMode={darkMode} locations={interestingLocations} />
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;
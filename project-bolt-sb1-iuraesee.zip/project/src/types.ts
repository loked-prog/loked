export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: string;
  difficulty: 'easy' | 'medium' | 'hard';
  explanation?: string;
  points: number;
  relatedLocationId?: number;
}

export interface MapLocation {
  id: number;
  name: string;
  coordinates: [number, number];
  description: string;
  type: 'wonder' | 'historical' | 'natural';
  imageUrl?: string;
  isQuizHint?: boolean;
}

export interface LeaderboardEntry {
  name: string;
  score: number;
  difficulty: 'easy' | 'medium' | 'hard';
  date: string;
}